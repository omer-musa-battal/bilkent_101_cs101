import java.util.Scanner;

/**
 * A basic java program
 * prints 'Start...' and 'End.'
 * @author Omer Musa Battal
 * @version 20.10.2016
 */ 
public class Lab02a
{
   public static void main( String[] args)
   {
      Scanner scan = new Scanner( System.in);
      
      // constants
      
      // variables
      
      // program code
      System.out.println( "Start...");
      
      
      System.out.println( "End.");
   }
   
}